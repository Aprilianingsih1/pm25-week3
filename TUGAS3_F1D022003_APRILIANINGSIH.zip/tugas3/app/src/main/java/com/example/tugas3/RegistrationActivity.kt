package com.example.tugas3

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.regex.Pattern

class RegistrationActivity : AppCompatActivity() {
    
    private lateinit var nameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var registerButton: Button
    private lateinit var loginLink: TextView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
        
        // Initialize views
        nameEditText = findViewById(R.id.nameEditText)
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        registerButton = findViewById(R.id.registerButton)
        loginLink = findViewById(R.id.loginLink)
        
        // Set click listeners
        registerButton.setOnClickListener {
            handleRegistration()
        }
        
        loginLink.setOnClickListener {
            navigateToLogin()
        }
    }
    
    private fun handleRegistration() {
        val name = nameEditText.text.toString().trim()
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()
        
        // Validate input
        if (!validateInput(name, email, password)) {
            return
        }
        
        // Create user object
        val user = User(
            name = name,
            email = email,
            password = password
        )
        
        // Navigate to landing screen
        val intent = Intent(this, LandingActivity::class.java)
        intent.putExtra("user", user)
        startActivity(intent)
        finish() // Close registration activity
    }
    
    private fun validateInput(name: String, email: String, password: String): Boolean {
        if (name.isEmpty()) {
            nameEditText.error = "Name is required"
            return false
        }
        
        if (name.length < 2) {
            nameEditText.error = "Name must be at least 2 characters"
            return false
        }
        
        if (email.isEmpty()) {
            emailEditText.error = "Email is required"
            return false
        }
        
        if (!isValidEmail(email)) {
            emailEditText.error = "Please enter a valid email"
            return false
        }
        
        if (password.isEmpty()) {
            passwordEditText.error = "Password is required"
            return false
        }
        
        if (password.length < 6) {
            passwordEditText.error = "Password must be at least 6 characters"
            return false
        }
        
        return true
    }
    
    private fun isValidEmail(email: String): Boolean {
        val emailPattern = Pattern.compile(
            "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        )
        return emailPattern.matcher(email).matches()
    }
    
    private fun navigateToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish() // Close registration activity
    }
} 