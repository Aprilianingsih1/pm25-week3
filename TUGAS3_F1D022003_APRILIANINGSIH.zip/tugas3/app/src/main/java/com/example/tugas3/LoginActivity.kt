package com.example.tugas3

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.regex.Pattern

class LoginActivity : AppCompatActivity() {
    
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var registerLink: TextView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        
        // Initialize views
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.loginButton)
        registerLink = findViewById(R.id.registerLink)
        
        // Set click listeners
        loginButton.setOnClickListener {
            handleLogin()
        }
        
        registerLink.setOnClickListener {
            navigateToRegistration()
        }
    }
    
    private fun handleLogin() {
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()
        
        // Validate input
        if (!validateInput(email, password)) {
            return
        }
        
        // For demo purposes, we'll create a user with the email as name
        // In a real app, you would authenticate against a backend
        val user = User(
            name = email.split("@").firstOrNull() ?: "User",
            email = email,
            password = password
        )
        
        // Navigate to landing screen
        val intent = Intent(this, LandingActivity::class.java)
        intent.putExtra("user", user)
        startActivity(intent)
    }
    
    private fun validateInput(email: String, password: String): Boolean {
        if (email.isEmpty()) {
            emailEditText.error = "Email is required"
            return false
        }
        
        if (!isValidEmail(email)) {
            emailEditText.error = "Please enter a valid email"
            return false
        }
        
        if (password.isEmpty()) {
            passwordEditText.error = "Password is required"
            return false
        }
        
        if (password.length < 6) {
            passwordEditText.error = "Password must be at least 6 characters"
            return false
        }
        
        return true
    }
    
    private fun isValidEmail(email: String): Boolean {
        val emailPattern = Pattern.compile(
            "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        )
        return emailPattern.matcher(email).matches()
    }
    
    private fun navigateToRegistration() {
        val intent = Intent(this, RegistrationActivity::class.java)
        startActivity(intent)
    }
} 