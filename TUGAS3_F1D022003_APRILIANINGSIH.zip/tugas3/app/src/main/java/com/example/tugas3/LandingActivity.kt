package com.example.tugas3

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LandingActivity : AppCompatActivity() {
    
    private lateinit var welcomeTextView: TextView
    private lateinit var userEmailTextView: TextView
    private lateinit var logoutButton: Button
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_landing)
        
        // Initialize views
        welcomeTextView = findViewById(R.id.welcomeTextView)
        userEmailTextView = findViewById(R.id.userEmailTextView)
        logoutButton = findViewById(R.id.logoutButton)
        
        // Get user data from intent
        val user = intent.getParcelableExtra<User>("user")
        
        if (user != null) {
            // Display user information
            welcomeTextView.text = "Welcome, ${user.name}!"
            userEmailTextView.text = "Email: ${user.email}"
        } else {
            // Fallback if no user data
            welcomeTextView.text = "Welcome!"
            userEmailTextView.text = "No user data available"
        }
        
        // Set logout button click listener
        logoutButton.setOnClickListener {
            navigateToLogin()
        }
    }
    
    private fun navigateToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
} 